

document.querySelector(".theme").addEventListener('click', ()=>{
   document.querySelector('body').classList.toggle('active');
   document.querySelector(".theme").classList.toggle('active');
})



document.querySelector("img").addEventListener('click', ()=>{
   document.querySelector('img').classList.toggle('active');
})
